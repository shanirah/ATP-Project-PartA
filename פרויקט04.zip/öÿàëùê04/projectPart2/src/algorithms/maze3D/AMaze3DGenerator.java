package algorithms.maze3D;

import algorithms.mazeGenerators.Maze;

public abstract class AMaze3DGenerator implements IMazeGenerator3D{

    public long measureAlgorithmTimeMillis(int depth, int row, int column){
        long start;
        long end;
        start = System.currentTimeMillis();
        generate(depth, row, column);
        end = System.currentTimeMillis();
        return (end - start);
    }

    protected Maze3D generateEmptyOrFull(int depth, int rows, int columns, int fill) {
        Maze3D newMaze;
        newMaze = new Maze3D(depth, rows, columns);
        int[][][] mat = newMaze.getMap();
        for (int z = 0; z < depth; z++) {
            for (int x = 0; x < rows; x++) {
                for (int y = 0; y < columns; y++) {
                    mat[z][x][y] = fill;
                }
            }
        }
        return newMaze;
    }

}
