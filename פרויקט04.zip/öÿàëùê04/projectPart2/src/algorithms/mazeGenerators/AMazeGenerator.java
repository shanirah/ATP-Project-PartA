package algorithms.mazeGenerators;

public abstract class AMazeGenerator implements IMazeGenerator {

    public abstract Maze generate(int rows, int columns);

    public long measureAlgorithmTimeMillis(int rows, int columns) {
        long start;
        long end;
        start = System.currentTimeMillis();
        generate(rows, columns);
        end = System.currentTimeMillis();
        return (end - start);
    }

    public boolean inBorders(int rowIndex, int colIndex, int rows, int columns) {
        if (rowIndex >= rows || colIndex >= columns || rowIndex < 0 || colIndex < 0)
            return false;
        return true;
    }

    protected Maze generateEmptyOrFull(int rows, int columns, int fill) {
        Maze newMaze;
        newMaze = new Maze(rows, columns);
        int[][] mat = newMaze.getMatrix();
        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < columns; y++) {
                mat[x][y] = fill;
            }
        }
        return newMaze;
    }
}