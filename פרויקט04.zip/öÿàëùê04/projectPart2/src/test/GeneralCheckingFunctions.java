package test;

public class GeneralCheckingFunctions {

    public static boolean check3DMaze(){
        boolean weChoseToDoTheMaze3DAssignment = true;
        return weChoseToDoTheMaze3DAssignment;
    }

}
